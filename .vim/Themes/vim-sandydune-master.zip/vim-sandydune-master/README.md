I like vim's built-in desert colorscheme, but I wanted more color.

Sandydune is a fork of desert that offers slight differentiation between different types (float vs int vs string) and used control statement colouring influenced by [codekana](http://www.codekana.com/).

See [a preview on vimcolors](http://vimcolors.com/209/sandydune/dark). In reality, you'll see more differentiation between numerical literals that aren't visible due to limitations in vimcolors.
